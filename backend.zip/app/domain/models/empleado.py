"""
Entidades de dominio para Empleados.

El CURP es el identificador único real (gobierno mexicano).
La clave interna (B25-00001) es para uso operativo del sistema.
"""
import re
from datetime import date, datetime
from typing import Optional
from uuid import UUID
from pydantic import BaseModel, Field, field_validator, ConfigDict

from app.domain.enums import EstatusEmpleado, GeneroEmpleado, MotivoBaja
from app.core.error_messages import msg_entidad_ya_estado
from app.core.validation import (
    # Patrones
    CURP_PATTERN,
    RFC_PERSONA_PATTERN,
    NSS_PATTERN,
    CLAVE_EMPLEADO_PATTERN,
    # Constantes de longitud
    CURP_LEN,
    RFC_PERSONA_LEN,
    NSS_LEN,
    CLAVE_EMPLEADO_MAX,
    NOMBRE_EMPLEADO_MIN,
    NOMBRE_EMPLEADO_MAX,
    APELLIDO_MIN,
    APELLIDO_MAX,
    CONTACTO_EMERGENCIA_MAX,
    NOTAS_MAX,
    EMAIL_MAX,
    TELEFONO_DIGITOS,
    DIRECCION_MAX,
    CUENTA_BANCARIA_MAX,
    BANCO_MAX,
    CLABE_LEN,
)
from app.core.validation.employee_validators import (
    validar_clabe_empleado,
    validar_cuenta_bancaria_empleado,
)
from app.core.validation.bank_validators import (
    normalizar_clabe_interbancaria,
    normalizar_cuenta_bancaria,
    normalizar_nombre_banco,
)


class Empleado(BaseModel):
    """
    Entidad principal de Empleado.

    El CURP es el identificador único real (gobierno).
    La clave (B25-00001) es para uso operativo interno y nunca cambia.
    El empleado puede cambiar de empresa (proveedor) manteniendo su clave e historial.
    """

    model_config = ConfigDict(
        use_enum_values=True,
        str_strip_whitespace=True,
        validate_assignment=True,
        from_attributes=True
    )

    # Identificación interna
    id: Optional[int] = None
    uuid: Optional[UUID] = Field(
        default=None,
        description="UUID público para rutas seguras del portal",
    )
    clave: str = Field(
        max_length=CLAVE_EMPLEADO_MAX,
        pattern=CLAVE_EMPLEADO_PATTERN,
        description="Clave permanente única: B25-00001"
    )
    empresa_id: Optional[int] = Field(None, description="ID del proveedor actual")

    # Identificación oficial
    curp: str = Field(
        min_length=CURP_LEN,
        max_length=CURP_LEN,
        description="CURP - Identificador único del gobierno mexicano"
    )
    rfc: Optional[str] = Field(
        None,
        min_length=RFC_PERSONA_LEN,
        max_length=RFC_PERSONA_LEN,
        description="RFC persona física (13 caracteres)"
    )
    nss: Optional[str] = Field(
        None,
        min_length=NSS_LEN,
        max_length=NSS_LEN,
        description="Número de Seguro Social IMSS"
    )

    # Datos personales
    nombre: str = Field(min_length=NOMBRE_EMPLEADO_MIN, max_length=NOMBRE_EMPLEADO_MAX)
    apellido_paterno: str = Field(min_length=APELLIDO_MIN, max_length=APELLIDO_MAX)
    apellido_materno: Optional[str] = Field(None, max_length=APELLIDO_MAX)
    fecha_nacimiento: Optional[date] = None
    genero: Optional[GeneroEmpleado] = None

    # Contacto
    telefono: Optional[str] = Field(None, max_length=TELEFONO_DIGITOS)
    email: Optional[str] = Field(None, max_length=EMAIL_MAX)
    direccion: Optional[str] = Field(None, max_length=DIRECCION_MAX)
    contacto_emergencia: Optional[str] = Field(
        None,
        max_length=CONTACTO_EMERGENCIA_MAX,
        description="Nombre y teléfono de contacto de emergencia"
    )

    # Estado laboral
    estatus: EstatusEmpleado = Field(default=EstatusEmpleado.ACTIVO)
    fecha_ingreso: date = Field(default_factory=date.today)
    fecha_ingreso_vigente: date = Field(default_factory=date.today)
    fecha_baja: Optional[date] = None
    motivo_baja: Optional[MotivoBaja] = None

    # Notas
    notas: Optional[str] = Field(None, max_length=NOTAS_MAX)

    # Restricción (solo admin BUAP puede modificar)
    is_restricted: bool = Field(
        default=False,
        description="true = empleado bloqueado por BUAP"
    )
    restriction_reason: Optional[str] = Field(
        None,
        max_length=500,
        description="Motivo de la restriccion (solo visible para admins)"
    )
    restricted_at: Optional[datetime] = Field(
        None,
        description="Fecha/hora de la restriccion"
    )
    restricted_by: Optional[UUID] = Field(
        None,
        description="UUID del admin que aplico la restriccion"
    )

    # Datos bancarios
    cuenta_bancaria: Optional[str] = Field(None, max_length=18)
    banco: Optional[str] = Field(None, max_length=100)
    clabe_interbancaria: Optional[str] = Field(None, max_length=18)

    # Datos adicionales
    entidad_nacimiento: Optional[str] = Field(None, max_length=100)
    renapo_validado: bool = False
    renapo_fecha_validacion: Optional[datetime] = None

    # Onboarding
    estatus_onboarding: Optional[str] = Field(default='REGISTRADO')

    # Autoservicio
    user_id: Optional[UUID] = Field(None)
    requiere_cambio_password: bool = True
    fecha_primer_acceso: Optional[datetime] = None

    # Sede
    sede_id: Optional[int] = Field(None)

    # Auditoría
    fecha_creacion: Optional[datetime] = None
    fecha_actualizacion: Optional[datetime] = None

    # =========================================================================
    # VALIDADORES
    # =========================================================================

    @field_validator('curp', mode='before')
    @classmethod
    def validar_curp(cls, v: str) -> str:
        """Valida formato de CURP."""
        if v:
            v = v.upper().strip()
            if len(v) != CURP_LEN:
                raise ValueError(f'CURP debe tener {CURP_LEN} caracteres (tiene {len(v)})')
            if not re.match(CURP_PATTERN, v):
                raise ValueError('CURP con formato inválido')
        return v

    @field_validator('rfc', mode='before')
    @classmethod
    def validar_rfc(cls, v: Optional[str]) -> Optional[str]:
        """Valida formato de RFC persona física."""
        if v:
            v = v.upper().strip()
            if len(v) != RFC_PERSONA_LEN:
                raise ValueError(f'RFC debe tener {RFC_PERSONA_LEN} caracteres (tiene {len(v)})')
            if not re.match(RFC_PERSONA_PATTERN, v):
                raise ValueError('RFC con formato inválido')
        return v

    @field_validator('nss', mode='before')
    @classmethod
    def validar_nss(cls, v: Optional[str]) -> Optional[str]:
        """Valida formato de NSS."""
        if v:
            v = v.strip()
            if not re.match(NSS_PATTERN, v):
                raise ValueError('NSS debe tener 11 dígitos numéricos')
        return v

    @field_validator('nombre', 'apellido_paterno', 'apellido_materno', mode='before')
    @classmethod
    def normalizar_nombre(cls, v: Optional[str]) -> Optional[str]:
        """Normaliza nombres a mayúsculas."""
        if v:
            return v.upper().strip()
        return v

    @field_validator('email', mode='before')
    @classmethod
    def validar_email(cls, v: Optional[str]) -> Optional[str]:
        """Valida formato de email."""
        if v:
            v = v.lower().strip()
            if '@' not in v or '.' not in v:
                raise ValueError('Email con formato inválido')
        return v

    @field_validator('telefono', mode='before')
    @classmethod
    def validar_telefono(cls, v: Optional[str]) -> Optional[str]:
        """Valida teléfono (solo 10 dígitos)."""
        if v:
            v = re.sub(r'[^0-9]', '', v)
            if len(v) != TELEFONO_DIGITOS:
                raise ValueError(f'Teléfono debe tener {TELEFONO_DIGITOS} dígitos')
        return v

    @field_validator('fecha_baja', mode='after')
    @classmethod
    def validar_fecha_baja(cls, v: Optional[date], info) -> Optional[date]:
        """Valida que fecha_baja sea >= fecha_ingreso_vigente."""
        if v and ('fecha_ingreso_vigente' in info.data or 'fecha_ingreso' in info.data):
            fecha_ingreso = (
                info.data.get('fecha_ingreso_vigente')
                or info.data.get('fecha_ingreso')
            )
            if fecha_ingreso and v < fecha_ingreso:
                raise ValueError('Fecha de baja no puede ser anterior a fecha de ingreso')
        return v

    # =========================================================================
    # MÉTODOS DE CONSULTA
    # =========================================================================

    def esta_restringido(self) -> bool:
        """Verifica si el empleado tiene restriccion activa."""
        return self.is_restricted

    def esta_activo(self) -> bool:
        """Retorna True si el empleado está activo."""
        return self.estatus == EstatusEmpleado.ACTIVO

    def esta_inactivo(self) -> bool:
        """Retorna True si el empleado está inactivo."""
        return self.estatus == EstatusEmpleado.INACTIVO

    def esta_suspendido(self) -> bool:
        """Retorna True si el empleado está suspendido."""
        return self.estatus == EstatusEmpleado.SUSPENDIDO

    def nombre_completo(self) -> str:
        """Retorna el nombre completo del empleado."""
        partes = [self.nombre, self.apellido_paterno]
        if self.apellido_materno:
            partes.append(self.apellido_materno)
        return " ".join(partes)

    def nombre_corto(self) -> str:
        """Retorna nombre y apellido paterno."""
        return f"{self.nombre} {self.apellido_paterno}"

    def edad(self) -> Optional[int]:
        """Calcula la edad basada en fecha_nacimiento."""
        if not self.fecha_nacimiento:
            return None
        hoy = date.today()
        edad = hoy.year - self.fecha_nacimiento.year
        if (hoy.month, hoy.day) < (self.fecha_nacimiento.month, self.fecha_nacimiento.day):
            edad -= 1
        return edad

    def antiguedad_dias(self) -> int:
        """Calcula días de antigüedad desde el ingreso vigente."""
        fecha_fin = self.fecha_baja or date.today()
        return (fecha_fin - (self.fecha_ingreso_vigente or self.fecha_ingreso)).days

    def antiguedad_anios(self) -> float:
        """Calcula años de antigüedad."""
        return round(self.antiguedad_dias() / 365.25, 1)

    # =========================================================================
    # MÉTODOS DE CAMBIO DE ESTADO
    # =========================================================================

    def activar(self):
        """Activa el empleado."""
        if self.estatus == EstatusEmpleado.ACTIVO:
            raise ValueError(msg_entidad_ya_estado("El empleado", "activo"))
        self.estatus = EstatusEmpleado.ACTIVO
        self.fecha_baja = None
        self.motivo_baja = None

    def suspender(self):
        """Suspende el empleado."""
        if self.estatus == EstatusEmpleado.SUSPENDIDO:
            raise ValueError(msg_entidad_ya_estado("El empleado", "suspendido"))
        self.estatus = EstatusEmpleado.SUSPENDIDO

    def dar_de_baja(self, motivo: MotivoBaja, fecha: Optional[date] = None):
        """Da de baja al empleado con motivo y fecha."""
        if self.estatus == EstatusEmpleado.INACTIVO:
            raise ValueError(msg_entidad_ya_estado("El empleado", "dado de baja"))
        self.estatus = EstatusEmpleado.INACTIVO
        self.fecha_baja = fecha or date.today()
        self.motivo_baja = motivo

    # =========================================================================
    # MÉTODOS ESTÁTICOS
    # =========================================================================

    @staticmethod
    def generar_clave(anio: int, consecutivo: int) -> str:
        """
        Genera clave de empleado: B25-00001

        Args:
            anio: Año de registro (ej: 2025)
            consecutivo: Número consecutivo del año

        Returns:
            Clave formateada (ej: B25-00001)
        """
        anio_corto = str(anio)[-2:]
        return f"B{anio_corto}-{consecutivo:05d}"

    def __str__(self) -> str:
        return f"{self.clave} - {self.nombre_completo()}"


class EmpleadoCreate(BaseModel):
    """
    Modelo para crear un nuevo empleado.
    La clave se genera automáticamente en el servicio.
    """

    model_config = ConfigDict(
        use_enum_values=True,
        str_strip_whitespace=True,
        validate_assignment=True
    )

    empresa_id: Optional[int] = None
    curp: str = Field(min_length=CURP_LEN, max_length=CURP_LEN)
    rfc: Optional[str] = Field(None, max_length=RFC_PERSONA_LEN)
    nss: Optional[str] = Field(None, max_length=NSS_LEN)
    nombre: str = Field(min_length=NOMBRE_EMPLEADO_MIN, max_length=NOMBRE_EMPLEADO_MAX)
    apellido_paterno: str = Field(min_length=APELLIDO_MIN, max_length=APELLIDO_MAX)
    apellido_materno: Optional[str] = Field(None, max_length=APELLIDO_MAX)
    fecha_nacimiento: Optional[date] = None
    genero: Optional[GeneroEmpleado] = None
    telefono: Optional[str] = Field(None, max_length=TELEFONO_DIGITOS)
    email: Optional[str] = Field(None, max_length=EMAIL_MAX)
    direccion: Optional[str] = Field(None, max_length=DIRECCION_MAX)
    contacto_emergencia: Optional[str] = Field(None, max_length=CONTACTO_EMERGENCIA_MAX)
    fecha_ingreso: Optional[date] = None
    fecha_ingreso_vigente: Optional[date] = None
    notas: Optional[str] = Field(None, max_length=NOTAS_MAX)
    cuenta_bancaria: Optional[str] = Field(None, max_length=CUENTA_BANCARIA_MAX)
    banco: Optional[str] = Field(None, max_length=BANCO_MAX)
    clabe_interbancaria: Optional[str] = Field(None, max_length=CLABE_LEN)

    # Validadores reutilizados
    validar_curp = field_validator('curp', mode='before')(Empleado.validar_curp.__func__)
    validar_rfc = field_validator('rfc', mode='before')(Empleado.validar_rfc.__func__)
    validar_nss = field_validator('nss', mode='before')(Empleado.validar_nss.__func__)
    normalizar_nombre = field_validator('nombre', 'apellido_paterno', 'apellido_materno', mode='before')(
        Empleado.normalizar_nombre.__func__
    )
    validar_email_create = field_validator('email', mode='before')(Empleado.validar_email.__func__)
    validar_telefono_create = field_validator('telefono', mode='before')(Empleado.validar_telefono.__func__)

    @field_validator('clabe_interbancaria', mode='before')
    @classmethod
    def validar_clabe_create(cls, v: Optional[str]) -> Optional[str]:
        """Valida CLABE interbancaria (18 dígitos)."""
        if v:
            v = normalizar_clabe_interbancaria(v)
            error = validar_clabe_empleado(v)
            if error:
                raise ValueError(error)
        return v

    @field_validator('cuenta_bancaria', mode='before')
    @classmethod
    def validar_cuenta_create(cls, v: Optional[str]) -> Optional[str]:
        """Valida cuenta bancaria (10-18 dígitos)."""
        if v:
            v = normalizar_cuenta_bancaria(v)
            error = validar_cuenta_bancaria_empleado(v)
            if error:
                raise ValueError(error)
        return v

    @field_validator('banco', mode='before')
    @classmethod
    def normalizar_banco_create(cls, v: Optional[str]) -> Optional[str]:
        """Normaliza banco a mayúsculas antes de persistir."""
        if v:
            return normalizar_nombre_banco(v)
        return v


class EmpleadoUpdate(BaseModel):
    """
    Modelo para actualizar un empleado existente.
    CURP y clave NO se pueden modificar.
    """

    model_config = ConfigDict(
        use_enum_values=True,
        str_strip_whitespace=True,
        validate_assignment=True
    )

    # empresa_id puede cambiar (cambio de proveedor)
    empresa_id: Optional[int] = None

    # CURP NO se puede cambiar - no incluido

    rfc: Optional[str] = Field(None, max_length=RFC_PERSONA_LEN)
    nss: Optional[str] = Field(None, max_length=NSS_LEN)
    nombre: Optional[str] = Field(None, min_length=NOMBRE_EMPLEADO_MIN, max_length=NOMBRE_EMPLEADO_MAX)
    apellido_paterno: Optional[str] = Field(None, min_length=APELLIDO_MIN, max_length=APELLIDO_MAX)
    apellido_materno: Optional[str] = Field(None, max_length=APELLIDO_MAX)
    fecha_nacimiento: Optional[date] = None
    genero: Optional[GeneroEmpleado] = None
    telefono: Optional[str] = Field(None, max_length=TELEFONO_DIGITOS)
    email: Optional[str] = Field(None, max_length=EMAIL_MAX)
    direccion: Optional[str] = Field(None, max_length=DIRECCION_MAX)
    contacto_emergencia: Optional[str] = Field(None, max_length=CONTACTO_EMERGENCIA_MAX)
    estatus: Optional[EstatusEmpleado] = None
    fecha_ingreso: Optional[date] = None
    fecha_ingreso_vigente: Optional[date] = None
    fecha_baja: Optional[date] = None
    motivo_baja: Optional[MotivoBaja] = None
    notas: Optional[str] = Field(None, max_length=NOTAS_MAX)

    # Campos de restriccion (solo admins pueden modificar via servicio)
    is_restricted: Optional[bool] = None
    restriction_reason: Optional[str] = Field(None, max_length=500)
    restricted_at: Optional[datetime] = None
    restricted_by: Optional[UUID] = None

    # Onboarding / autoservicio
    estatus_onboarding: Optional[str] = None
    user_id: Optional[UUID] = None
    sede_id: Optional[int] = None

    # Datos bancarios
    cuenta_bancaria: Optional[str] = Field(None, max_length=18)
    banco: Optional[str] = Field(None, max_length=100)
    clabe_interbancaria: Optional[str] = Field(None, max_length=18)

    # Datos adicionales
    entidad_nacimiento: Optional[str] = Field(None, max_length=100)

    # Validadores reutilizados
    validar_rfc_update = field_validator('rfc', mode='before')(Empleado.validar_rfc.__func__)
    validar_nss_update = field_validator('nss', mode='before')(Empleado.validar_nss.__func__)
    normalizar_nombre_update = field_validator(
        'nombre', 'apellido_paterno', 'apellido_materno', mode='before'
    )(Empleado.normalizar_nombre.__func__)
    validar_email_update = field_validator('email', mode='before')(Empleado.validar_email.__func__)
    validar_telefono_update = field_validator('telefono', mode='before')(Empleado.validar_telefono.__func__)

    @field_validator('clabe_interbancaria', mode='before')
    @classmethod
    def validar_clabe_update(cls, v: Optional[str]) -> Optional[str]:
        """Valida CLABE interbancaria (18 dígitos)."""
        if v:
            v = normalizar_clabe_interbancaria(v)
            error = validar_clabe_empleado(v)
            if error:
                raise ValueError(error)
        return v

    @field_validator('cuenta_bancaria', mode='before')
    @classmethod
    def validar_cuenta_update(cls, v: Optional[str]) -> Optional[str]:
        """Valida cuenta bancaria (10-18 dígitos)."""
        if v:
            v = normalizar_cuenta_bancaria(v)
            error = validar_cuenta_bancaria_empleado(v)
            if error:
                raise ValueError(error)
        return v

    @field_validator('banco', mode='before')
    @classmethod
    def normalizar_banco_update(cls, v: Optional[str]) -> Optional[str]:
        """Normaliza banco a mayúsculas antes de persistir."""
        if v:
            return normalizar_nombre_banco(v)
        return v


class EmpleadoResumen(BaseModel):
    """
    Modelo resumido de empleado para listados.
    Optimizado para mostrar en tablas y cards.
    """

    model_config = ConfigDict(
        use_enum_values=True,
        from_attributes=True
    )

    id: int
    uuid: Optional[UUID] = None
    clave: str
    curp: str
    nombre_completo: str
    empresa_id: Optional[int] = None
    empresa_nombre: Optional[str] = None
    estatus: EstatusEmpleado
    is_restricted: bool = False
    fecha_ingreso: date
    fecha_ingreso_vigente: Optional[date] = None
    telefono: Optional[str] = None
    email: Optional[str] = None
    estatus_onboarding: Optional[str] = None
    documentos_aprobados_expediente: int = 0
    documentos_requeridos_expediente: int = 0
    descuentos_configurados: list[dict] = Field(default_factory=list)
    descuentos_activos_hoy: list[dict] = Field(default_factory=list)

    @classmethod
    def from_empleado(
        cls,
        empleado: Empleado,
        empresa_nombre: Optional[str] = None,
        *,
        documentos_aprobados_expediente: int = 0,
        documentos_requeridos_expediente: int = 0,
        descuentos_configurados: Optional[list[dict]] = None,
        descuentos_activos_hoy: Optional[list[dict]] = None,
    ) -> 'EmpleadoResumen':
        """Factory method para crear desde un empleado completo."""
        return cls(
            id=empleado.id,
            uuid=empleado.uuid,
            clave=empleado.clave,
            curp=empleado.curp,
            nombre_completo=empleado.nombre_completo(),
            empresa_id=empleado.empresa_id,
            empresa_nombre=empresa_nombre,
            estatus=empleado.estatus,
            is_restricted=empleado.is_restricted,
            fecha_ingreso=empleado.fecha_ingreso,
            fecha_ingreso_vigente=empleado.fecha_ingreso_vigente,
            telefono=empleado.telefono,
            email=empleado.email,
            estatus_onboarding=empleado.estatus_onboarding,
            documentos_aprobados_expediente=documentos_aprobados_expediente,
            documentos_requeridos_expediente=documentos_requeridos_expediente,
            descuentos_configurados=descuentos_configurados or [],
            descuentos_activos_hoy=descuentos_activos_hoy or [],
        )

    @classmethod
    def from_empleado_dict(
        cls,
        data: dict,
        empresa_nombre: Optional[str] = None,
        *,
        documentos_aprobados_expediente: int = 0,
        documentos_requeridos_expediente: int = 0,
        descuentos_configurados: Optional[list[dict]] = None,
        descuentos_activos_hoy: Optional[list[dict]] = None,
    ) -> 'EmpleadoResumen':
        """Factory method para crear desde un diccionario de BD."""
        # Construir nombre completo
        nombre = data.get('nombre', '')
        apellido_p = data.get('apellido_paterno', '')
        apellido_m = data.get('apellido_materno', '')
        nombre_completo = f"{nombre} {apellido_p}".strip()
        if apellido_m:
            nombre_completo = f"{nombre_completo} {apellido_m}"

        return cls(
            id=data['id'],
            uuid=data.get('uuid'),
            clave=data['clave'],
            curp=data['curp'],
            nombre_completo=nombre_completo,
            empresa_id=data['empresa_id'],
            empresa_nombre=empresa_nombre,
            estatus=data['estatus'],
            is_restricted=data.get('is_restricted', False),
            fecha_ingreso=data['fecha_ingreso'],
            fecha_ingreso_vigente=data.get('fecha_ingreso_vigente'),
            telefono=data.get('telefono'),
            email=data.get('email'),
            estatus_onboarding=data.get('estatus_onboarding'),
            documentos_aprobados_expediente=documentos_aprobados_expediente,
            documentos_requeridos_expediente=documentos_requeridos_expediente,
            descuentos_configurados=descuentos_configurados or [],
            descuentos_activos_hoy=descuentos_activos_hoy or [],
        )
