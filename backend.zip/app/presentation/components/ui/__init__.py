"""Componentes genéricos de UI reutilizables"""

from .headers import page_header
from .form_input import (
    form_field,
    form_input,
    form_select,
    form_textarea,
    form_date,
    filter_date_input,
    compact_date_input,
    form_row,
    select_items_from_options,
)
from .accumulating_select import accumulating_select
from .badges import estatus_badge, badge_onboarding, identifier_badge
from .badges_domain import (
    employee_status_badge,
    document_status_badge,
    payroll_period_status_badge,
)
from app.presentation.theme.feedback import (
    DEFAULT_TOAST_POSITION,
    app_toast,
    feedback_callout,
)
from .tables import tabla_vacia
from .table_primitives import (
    table_cell_text,
    table_cell_text_sm,
    table_cell_badge,
    table_cell_actions,
    table_header_cells,
    table_pagination,
    table_shell,
    table_text,
    table_text_sm,
)
from .skeletons import skeleton_tabla
from .filters import (
    input_busqueda,
    indicador_filtros,
    contador_registros,
    acciones_filtros,
    filtros_inline,
    filter_pill,
    switch_inactivos,
    barra_filtros,
    select_estatus_onboarding,
)
from .modals import (
    modal_confirmar_eliminar,
    modal_confirmar_accion,
    modal_formulario,
    modal_detalle,
)

from .status_badge import (
    status_badge,
    status_badge_reactive,
)

from .view_toggle import (
    view_toggle,
)

from .breadcrumb import (
    breadcrumb_dynamic,
)

from .action_buttons import (
    # Nuevos (usar estos)
    tabla_action_button,
    tabla_action_buttons,
    tabla_cta_button,
    ACTION_BUTTON_SIZE,
    ACTION_ICON_SIZE,
    ACTION_BUTTON_VARIANT,
    ACTION_BUTTONS_SPACING,
    action_buttons_reactive,
)

from .segmented_tabs import (
    segmented_tab_trigger,
    segmented_tabs,
)

from .entity_card import (
    entity_card,
    entity_grid,
)

from .metric_card import metric_card
from .cards import empty_state_card
from .detail_fields import (
    detail_label,
    section_title,
    modal_section_label,
    fallback_text,
    detail_text_item,
    detail_link_item,
    metadata_item,
    metadata_divider,
)

from .notification_bell import (
    notification_bell,
    notification_bell_portal,
    NotificationBellState,
)

from .buttons import (
    boton_guardar,
    boton_cancelar,
    boton_eliminar,
    botones_modal,
)


__all__ = [
    'page_header',
    # formularios
    'form_field',
    'form_input',
    'form_select',
    'form_textarea',
    'form_date',
    'filter_date_input',
    'compact_date_input',
    'form_row',
    'select_items_from_options',
    'accumulating_select',
    'estatus_badge',
    'payroll_period_status_badge',
    'employee_status_badge',
    'document_status_badge',
    'badge_onboarding',
    'identifier_badge',
    'DEFAULT_TOAST_POSITION',
    'app_toast',
    'feedback_callout',
    # tablas
    'tabla_vacia',
    'table_header_cells',
    'table_pagination',
    'table_shell',
    'table_cell_text',
    'table_cell_text_sm',
    'table_cell_badge',
    'table_cell_actions',
    'table_text',
    'table_text_sm',
    'skeleton_tabla',
    # filtros
    'input_busqueda',
    'indicador_filtros',
    'contador_registros',
    'acciones_filtros',
    'filtros_inline',
    'filter_pill',
    'switch_inactivos',
    'barra_filtros',
    'select_estatus_onboarding',
    # modales
    'modal_confirmar_eliminar',
    'modal_confirmar_accion',
    'modal_formulario',
    'modal_detalle',
    # Status badges
    "status_badge",
    "status_badge_reactive",
    # View toggle
    "view_toggle",
    # Breadcrumb
    "breadcrumb_dynamic",
    # Action buttons (nuevos)
    "tabla_action_button",
    "tabla_action_buttons",
    "tabla_cta_button",
    "ACTION_BUTTON_SIZE",
    "ACTION_ICON_SIZE",
    "ACTION_BUTTON_VARIANT",
    "ACTION_BUTTONS_SPACING",
    "action_buttons_reactive",
    "segmented_tab_trigger",
    "segmented_tabs",
    # Entity cards
    "entity_card",
    "entity_grid",
    # Metric card
    "metric_card",
    # Empty state card
    "empty_state_card",
    # Detail / metadata fields
    "detail_label",
    "section_title",
    "modal_section_label",
    "fallback_text",
    "detail_text_item",
    "detail_link_item",
    "metadata_item",
    "metadata_divider",
    # Notification bell
    "notification_bell",
    "notification_bell_portal",
    "NotificationBellState",
    # Buttons
    "boton_guardar",
    "boton_cancelar",
    "boton_eliminar",
    "botones_modal",
]
