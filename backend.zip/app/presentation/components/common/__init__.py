"""Componentes comunes reutilizables."""
