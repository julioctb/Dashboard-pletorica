"""
Page Layout - Estructura estándar de páginas.

Define la estructura visual consistente para páginas con header, toolbar y
área de contenido principal.
"""

import reflex as rx
from app.presentation.components.ui.headers import page_header as ui_page_header
from app.presentation.components.ui.view_toggle import view_toggle as ui_view_toggle
from app.presentation.components.ui.filters import input_busqueda
from app.presentation.theme import (
    Colors,
    Spacing,
    Radius,
    Typography,
)


# =============================================================================
# PAGE HEADER
# =============================================================================

def page_header(
    titulo: str,
    subtitulo: str = "",
    icono: str = None,
    accion_principal: rx.Component = None,
    titulo_compuesto: rx.Component = None,
    subtitulo_compuesto: rx.Component = None,
    show_divider: bool = True,
    color_icono: str | None = None,
) -> rx.Component:
    """Adapter compatible que delega al header shared de UI."""
    return rx.box(
        ui_page_header(
            icono=icono,
            titulo=titulo,
            subtitulo=subtitulo,
            titulo_compuesto=titulo_compuesto,
            subtitulo_compuesto=subtitulo_compuesto,
            accion_principal=accion_principal,
            color_icono=color_icono,
        ),
        width="100%",
        padding_bottom=Spacing.LG,
        margin_bottom=Spacing.MD,
        border_bottom=f"1px solid {Colors.BORDER}" if show_divider else "none",
    )


# =============================================================================
# VIEW TOGGLE (Tabla / Cards)
# =============================================================================

def view_toggle(
    current_view: str,
    on_change_table: callable,
    on_change_cards: callable,
) -> rx.Component:
    """
    Toggle para cambiar entre vista de tabla y cards.
    
    Args:
        current_view: "table" o "cards"
        on_change_table: Callback al seleccionar tabla
        on_change_cards: Callback al seleccionar cards
    """
    return ui_view_toggle(
        value=current_view,
        on_change_table=on_change_table,
        on_change_cards=on_change_cards,
    )


# =============================================================================
# PAGE TOOLBAR
# =============================================================================

def page_toolbar(
    # Mostrar/ocultar búsqueda
    show_search: bool = True,

    # Búsqueda
    search_value: str = "",
    search_placeholder: str = "Buscar...",
    on_search_change: callable = None,
    on_search_clear: callable = None,
    
    # Filtros (slot para componentes de filtro)
    filters: rx.Component = None,
    
    # Toggle de vista
    show_view_toggle: bool = True,
    current_view: str = "table",
    on_view_table: callable = None,
    on_view_cards: callable = None,
    
    # Elementos adicionales a la derecha
    extra_right: rx.Component = None,
    # Variante visual
    wrapped: bool = True,
    compact: bool = False,
    # Layout del campo de búsqueda
    search_min_width: str = "260px",
    search_max_width: str | None = "400px",
    search_flex: str = "1 1 300px",
) -> rx.Component:
    """
    Barra de herramientas estándar con búsqueda, filtros y toggle de vista.
    
    Args:
        search_value: Valor actual del campo de búsqueda
        search_placeholder: Placeholder del campo de búsqueda
        on_search_change: Callback al cambiar búsqueda
        on_search_clear: Callback al limpiar búsqueda
        filters: Componente de filtros (opcional)
        show_view_toggle: Mostrar toggle tabla/cards
        current_view: Vista actual ("table" o "cards")
        on_view_table: Callback para vista tabla
        on_view_cards: Callback para vista cards
        extra_right: Componentes adicionales al final (opcional)
    
    Ejemplo:
        page_toolbar(
            search_value=State.search,
            on_search_change=State.set_search,
            show_view_toggle=True,
            current_view=State.view_mode,
            on_view_table=State.set_view_table,
            on_view_cards=State.set_view_cards,
        )
    """
    column_gap = Spacing.SM if compact else Spacing.MD
    row_gap = Spacing.XS if compact else Spacing.SM

    left_group = rx.flex(
        rx.cond(
            show_search,
            rx.box(
                input_busqueda(
                    value=search_value,
                    on_change=on_search_change,
                    on_clear=on_search_clear,
                    placeholder=search_placeholder,
                    width="100%",
                    toolbar_style=True,
                ),
                width="100%",
                min_width=search_min_width,
                max_width=search_max_width or "none",
                flex=search_flex,
            ),
            rx.fragment(),
        ),
        filters if filters else rx.fragment(),
        wrap="wrap",
        align="center",
        column_gap=column_gap,
        row_gap=row_gap,
        flex="1 1 420px",
        width="100%",
    )

    right_group = rx.flex(
        extra_right if extra_right else rx.fragment(),
        rx.cond(
            show_view_toggle,
            view_toggle(
                current_view=current_view,
                on_change_table=on_view_table,
                on_change_cards=on_view_cards,
            ),
            rx.fragment(),
        ),
        wrap="wrap",
        align="center",
        justify="end",
        column_gap=column_gap,
        row_gap=row_gap,
    )

    toolbar = rx.flex(
        left_group,
        right_group,
        wrap="wrap",
        align="center",
        justify="between",
        width="100%",
        column_gap=column_gap,
        row_gap=row_gap,
    )

    if not wrapped:
        return rx.box(
            toolbar,
            width="100%",
            margin_bottom=Spacing.MD,
        )

    return rx.box(
        toolbar,
        width="100%",
        padding=Spacing.MD,
        background=Colors.SURFACE,
        border_radius=Radius.LG,
        border=f"1px solid {Colors.BORDER}",
        margin_bottom=Spacing.MD,
    )


# =============================================================================
# PAGE LAYOUT COMPLETO
# =============================================================================

def page_content_area(content: rx.Component) -> rx.Component:
    """
    Área de contenido principal de la página.
    """
    return rx.box(
        content,
        width="100%",
        flex="1",
    )


def page_layout(
    header: rx.Component = None,
    toolbar: rx.Component = None,
    content: rx.Component = None,
) -> rx.Component:
    """
    Layout completo de página con header, toolbar y contenido.
    
    Args:
        header: Componente de header (usar page_header())
        toolbar: Componente de toolbar (usar page_toolbar())
        content: Contenido principal de la página
    
    Ejemplo:
        def contratos_page():
            return page_layout(
                header=page_header(
                    titulo="Contratos",
                    subtitulo="Gestione los contratos",
                    icono="file-text",
                    accion_principal=boton_nuevo,
                ),
                toolbar=page_toolbar(
                    search_value=ContratosState.search,
                    ...
                ),
                content=tabla_contratos(),
            )
    """
    return rx.vstack(
        # Header (opcional)
        header if header else rx.fragment(),
        
        # Toolbar (opcional)
        toolbar if toolbar else rx.fragment(),
        
        # Contenido principal
        page_content_area(content) if content else rx.fragment(),
        
        width="100%",
        min_height="100%",
        spacing="0",
        align_items="stretch",
    )
