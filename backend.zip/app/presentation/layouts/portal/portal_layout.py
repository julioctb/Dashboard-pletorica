"""
Layout principal del portal de cliente.

Provee la funcion portal_index() que envuelve las paginas del portal
con el sidebar de cliente y el area de contenido.
"""
import reflex as rx

from app.presentation.layouts.backoffice.shell_layout import authenticated_sidebar_shell
from app.presentation.layouts.portal.portal_sidebar import portal_sidebar
from app.presentation.pages.portal.state.portal_state import PortalState
from app.presentation.theme import content_container


def portal_index(content: rx.Component) -> rx.Component:
    """
    Layout del portal: sidebar de cliente + contenido.

    Uso en core.py:
        app.add_page(
            lambda: portal_index(portal_dashboard_page()),
            route="/portal",
        )
    """
    return rx.box(
        authenticated_sidebar_shell(
            sidebar_component=portal_sidebar(),
            content=content_container(content),
        ),
        # Al cambiar de empresa, se remonta el shell completo y cada página
        # vuelve a ejecutar su on_mount con el nuevo contexto activo.
        key=PortalState.id_empresa_actual.to(str),
    )
